/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] iArray = new int[5];
        // Unchecked
        // ArrayIndexOutOfBoundsException
        // iArray[5] = 27;
        
        String s = null;
        // NullPointerException
        // System.out.println(s.toUpperCase());
        
        // Error
        // OutOfMemoryError
        var list = new ArrayList<String>();
        while(true){  // 無窮迴圈
            list.add("OutOfMemoryError");
            if(list.size() % 1000000 == 0){
                System.out.println("list 內元素個數：" + list.size()/1000000 + " 百萬筆");
            }
        }
    }
    
}
