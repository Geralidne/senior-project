/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        var a = 10;         // int
        var b = 2.34;       // double
        var c = a + b;      // double
        System.out.println("c：" + c);
        
        var d = "java";     // String
        System.out.println("d：" + d.toUpperCase());
        
        var sum = 0.0;      // double
        for(var i=1; i<=10; i++){
            sum += i;
        }
        System.out.println("sum：" + sum);
        
        // 陣列
        // var[] e = {1, 2, 3, 4};
        var e = new int[]{1, 2, 3, 4};
        for(var i : e){
            System.out.printf("%d | ", i);
        }
        System.out.println("");
        
        var f = doTest(10); 
        System.out.println("f：" + f);
        
        
    }
    
//    private static var doTest(var i){
//        return i * 10;
//    }
    
    private static int doTest(int i){
        return i * 10;
    }
    
}
