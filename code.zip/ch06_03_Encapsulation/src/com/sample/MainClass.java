/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Circle cir = new Circle();
        // cir.radius = -10; // 不可以直接存取 private 成員
        cir.setRadius(10);
        // cir.PI = 314; // 不可以修改 final 資料
        System.out.println("radius：" + cir.getRadius());
        System.out.println("PI：" + cir.PI);
        System.out.println("area：" + cir.area());
    }
    
}
