/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class Circle {
    // 屬性
    // public 公開
    // static 類別成員、由類別建立的物件公用
    // final 最終、不可以修改(常數)
    public static final double PI = 3.14;
    // private 私有不對外
    private double radius;
    
    // 計算面積的方法
    public double area(){
        return radius * radius * PI;
    }
    
    // 提供公開的操作介面(方法)讓外部可以間接操作私有成員
    // 設值方法 setXXX()
    public void setRadius(double radius){
        // 先檢查輸入的參數 radius 是否是正確
        if(radius >= 0){
            // 輸入的參數 radius 正確。就指定給屬性 this.radius
            this.radius = radius;
            drawCir();
        }else{
            System.out.println("【Error】半徑不可以小於 0");
            this.radius = 0.0;
        }
    }
    
    // 取值方法 getXXX()
    public double getRadius(){
        return radius;
    }
    
    // 私有方法
    private void drawCir(){
        System.out.println("繪製圓形...");
    }   
    
}
