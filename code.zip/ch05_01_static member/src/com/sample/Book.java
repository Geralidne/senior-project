/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class Book {
    // 類別成員：由這個類別建立的物件共同使用
    static int id;
    // 物件成員：由物件自己使用
    String bookId;
    String name;
    
    public Book(String name, char type){
        System.out.println("物件剛建立時，id = " + id);
        ++id;
        bookId = String.format("%c%03d", type, id); // J001、P002、A003
        System.out.println("id：" + id);
        System.out.println("bookId：" + bookId);
        this.name = name;
        System.out.println("name：" + this.name.toUpperCase());
        System.out.println("--------------------------");
    }
    
    // 物件成員方法
    public void info(){
        System.out.println("info()...");
        System.out.println("id：" + id);
        System.out.println("bookId：" + bookId);
        System.out.println("name：" + name);
        doTest1();
        doTrst2();
    }
    
    // 類別成員方法
    public static void showId(){
        System.out.println("目前 id：" + id);
//        類別成員不可以使用或呼叫物件成員
//        System.out.println("bookId：" + bookId);
//        System.out.println("name：" + name);
//        doTest1();
        doTrst2();
    } 
    
    public void doTest1(){
        System.out.println("doTest1()...");
    }
    
    public static void doTrst2(){
        System.out.println("doTest2()...");
    }
}
