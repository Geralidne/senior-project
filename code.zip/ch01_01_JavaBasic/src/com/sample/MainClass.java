/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 * 多行註解
 */
// 單行註解
// 套件區：分類管理類別，用來宣告該檔案中的類別是屬於哪一個Package(類別庫)，必須寫在程式的第一行
package com.sample;

// import 區
// 除 java.lang(預設套件) 及 類別所在的 package 可以不用 import, 其餘的皆需要 import 的宣告
import java.util.Scanner;
import java.util.Arrays;

/**
 * 
 * @author User
 * 文件註解
 */
// 類別區
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // 宣告區域變數：寫在方法內、區塊內的變數
        // 型別 變數名稱 = 值;
        String name1 = "Amy";
        int age1 = 10;
        double height1 = 135.7;        
        System.out.println("我是" + name1 + ",今年" + age1 + "歲,身高" + height1 + "公分");
        
        // 不提供變數的資料型別在等號的左側，透過標記變數為 var
        // 編譯器會依照等號右側的資料推論變數的型別
        // 限用在區域變數，並且明確給值
        var name2 = "Amy";
        var age2 = 10;
        var height2 = 135.7;
        System.out.println("我是" + name2+ ",今年" + age2 + "歲,身高" + height2 + "公分");
        System.out.println("-----------");
        
        // 格式化輸出 System.out.printf("格式化字串", 引數...)
        // %s 字串
        // %d 十進位整數
        // %f 浮點數
        // %c 字元
        // %b 布林值
        // %n 換行        
        System.out.printf("我是%s,今年%d歲,身高%f公分%n", name2, age2, height2);
        System.out.println("-----------");
        
        System.out.printf("|%d|%n", 654321);
        System.out.printf("|%8d|%n", 654321);
        System.out.printf("|%8d|%n", 54321);
        System.out.printf("|%8d|%n", 4321);
        System.out.printf("|%8d|%n", 321);
        System.out.printf("|%8d|%n", 21);
        System.out.printf("|%8d|%n", 1);
        System.out.println("-----------");
        
        System.out.printf("%c%04d%n", 'A', 1);
        System.out.printf("%c%04d%n", 'J', 25);
        System.out.printf("%c%04d%n", 'P', 2468);
        System.out.printf("%c%04d%n", 'S', 135);
        System.out.println("-----------");
        
        System.out.printf("%6.2f%n", 123.456789);
        System.out.printf("%6.2f%n", 12.3456789);
        System.out.printf("%6.2f%n", 1.23456789);
        System.out.println("-----------");
        
        // 使用【-】負號讓資料靠左對齊
        System.out.printf("|%10s|%n", "Java");
        System.out.printf("|%-10s|%n", "Java");
        System.out.printf("|%6d|%n", 123);
        System.out.printf("|%6d|%n", -123);
        System.out.printf("|%-6d|%n", -123);
        System.out.printf("|%-6d|%n", 123);
        System.out.printf("|%+6d|%n", 123);
        System.out.printf("|%+-6d|%n", 123);
        System.out.printf("|%+-6d|%n", -123);
        System.out.println("-----------");
        
        // 底線標示，標示時底線前、後必須是數字
        // int a1 = 2,147,483,647;   // 編譯失敗
        int a1 = 2_147_483_647;
        System.out.println("a1：" + a1);
        double a2 = 1___234_56.7_89__3____21;
        System.out.println("a2：" + a2);
        System.out.println("a3：" + 0b1010_0010_1101);
        System.out.println("-----------");
        
        System.out.println(19 / 5);
        System.out.println(19.0 / 5);
        System.out.println(19 / 5.0);
        System.out.println(19.0 / 5.0);
        System.out.println((double)19 / 5);   // 強制轉型：(目標型別)值
        
        // System.out.println(19 / 0);    // ArithmeticException: / by zero
        System.out.println(19 / 0.0);     // Infinity 正無限大
        System.out.println(-19 / 0.0);     // -Infinity 負無限大
        System.out.println("-----------");
        
        
        
        
        
        
    }
    
}
