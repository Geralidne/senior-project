/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // 未指定型別，加入集合的元素皆會轉換成 Object 型別
        // ArrayList 加入的元素都是物件
        // 建立 ArrayList 集合物件
        ArrayList objList = new ArrayList();
        // add() 加入元素到集合中
        objList.add(100);
        objList.add(new Integer(200));  // 不建議使用
        objList.add(1.23);
        objList.add("Java");
        objList.add('A');
        objList.add(true);
        objList.add(1.23);
        // 簡易顯示集合內容
        System.out.println("objList：" + objList);
        // 在指定索引值加入元素
        objList.add(1, "Java");
        // size() 查看集合的元素個數
        System.out.println("數量：" + objList.size());
        // get(index) 取出元素
        System.out.println("get(1)：" + objList.get(1));        
        // 使用一般 for 迴圈取出集合的元素
        for(int i=0; i<objList.size(); i++){
            System.out.print(objList.get(i) + " | ");
        }
        System.out.println("\n-----------------------------");
        // System.out.println("objList.get(2) / 2：" +(objList.get(2) / 2)); // 取出的 200 是 Object 型別不可以直接計算
        //         取出時先轉型回原來的型別
        var temp = (int)objList.get(2);
        System.out.printf("temp / 2：%d%n", temp/2);
        System.out.println("get(4)轉大寫：" + ((String)objList.get(4)).toUpperCase());
        System.out.println("objList：" + objList);
        System.out.println("-----------------------------");
        
        // 指定型別
        ArrayList<String> strList = new ArrayList();
        // strList.add(123);  // 非 String 型態資料不可以加入
        strList.add("python");
        strList.add("java");
        strList.add("android");
        strList.add("java");
        strList.add("sql");
        strList.add(new String(new char[]{'j', 'a', 'v', 'a'}));
        System.out.println("strList：" + strList);
        System.out.println("get(1)轉大寫：" + strList.get(1).toUpperCase());
        System.out.println("strList.indexOf(\"php\")：" + strList.indexOf("php"));      // 找不到符合的元素會回傳 -1
        System.out.println("strList.indexOf(\"java\")：" + strList.indexOf("java"));    // 若有找到會回傳第一個出現的元素的索引值
        // 修改元素 set(index, 新元素)
        System.out.println("strList.set(2, strList.get(2).toUpperCase())：" + strList.set(2, strList.get(2).toUpperCase()));
        // 移除元素
        System.out.println("strList.remove(4)：" + strList.remove(4));
        System.out.println("strList.remove(\"java\")：" + strList.remove("java"));
        System.out.println("strList.remove(\"android\")：" + strList.remove("android"));        
        // 使用增強型 for 迴圈
        for(String s : strList){
            System.out.print(s + " | ");
        }
        System.out.println("\n-----------------------------");
        // 清空集合元素
        strList.clear();
        System.out.println("strList 是否是空集合：" + strList.isEmpty());
        System.out.println("strList：" + strList);
        System.out.println("-----------------------------");
        
        var test1 = new ArrayList();   // <Object>
        // var<String> test2 = new ArrayList();
        var test2 = new ArrayList<String>();
        var test3 = test2;
        // -----------------------------------------
        
        // 建立 String 陣列
        String[] names = {"Ned", "Fred", "Jessie", "Alice", "Rick", "Amy", "Lisa", "Jackie"};
        
        // 將陣列資料放入 List 集合
        List<String> test4 = Arrays.asList(names);
        System.out.println("test4：" + test4);
        
        // 將陣列資料放入 ArrayList 集合
        ArrayList<String> test5 = new ArrayList(Arrays.asList(names));      // <String>
        var test6 = new ArrayList(Arrays.asList(names));                    // <Object>
        var test7 = new ArrayList<String>(Arrays.asList(names));            // <String> 
        System.out.println("test7：" + test7);
        System.out.println("----------------------------");
        
        // 將 test7 的元素轉大寫
        System.out.println("這是假象...");
        for(String s : test7){
            System.out.printf("%s | ", s.toUpperCase());
        }
        System.out.println("\n--------------------");
        System.out.println("test7：" + test7);
        System.out.println("--------------------");
        
        System.out.println("方法一 set()、get() 將 test7 的元素轉成大寫");
        for(int i=0; i<test7.size(); i++){
            test7.set(i, test7.get(i).toUpperCase());
        }
        System.out.println("test7：" + test7);
        System.out.println("--------------------");
        
        System.out.println("方法二 lambda Expression 將 test7 的元素轉成小寫");
        test7.replaceAll(s -> s.toLowerCase());
        System.out.println("test7：" + test7);
        System.out.println("--------------------");
        
        // 使用 Lambda Expression 將集合中的元素是 'a' 開始的名字移除
        test7.removeIf(s -> s.startsWith("a"));
        System.out.println("test7：" + test7);
        System.out.println("--------------------");
        
        // 使用 Lambda Expression 將集合中元素字串長度大於 4 個字的名字移除
        test7.removeIf(s -> s.length()>4);
        System.out.println("test7：" + test7);
        
    }
    
}
