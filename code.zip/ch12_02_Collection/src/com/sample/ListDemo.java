/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author User
 */
public class ListDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Integer> list = new ArrayList();
        list.add(new Integer(10));      // Java 5.0 前 boxing 裝箱(int  -> Integer)，不建議再使用
        list.add(20);                      // Java 5.0 開始 autoboxing 自動裝箱(int  -> Integer) 
        list.add(Integer.valueOf(30));
        list.add(Integer.valueOf("40"));
        System.out.println("list：" + list);
        
        int total1 = 0;
        for(int i=0; i<list.size(); i++){
            // 取出集合元素
            Integer wInt = list.get(i);
            int pInt = wInt.intValue();     // Java 5.0 前 unboxing 拆箱(Integer -> int)
            total1 += pInt;            
        }
        System.out.println("total1：" + total1);
        
        int total2 = 0;
        for(Integer wInt : list){
            int pInt = wInt;                // Java 5.0 開始 autounboxing 自動拆箱(Integer -> int)
            total2 += pInt;
        }
        System.out.println("total2：" + total2);
        
        int total3 = 0;
        for(int pInt : list){               // Java 5.0 開始 autounboxing 自動拆箱(Integer -> int)         
            total3 += pInt;
        }
        System.out.println("total3：" + total3);
        
        // 使用迭代器
        int total4 = 0;
        Iterator<Integer> iterator = list.iterator();  // 將 list 的元素複製一份放到 iterator 內   
        
        // iterator.forEachRemaining(i -> System.out.println(i));
        
        while(iterator.hasNext()){
            
            // iterator.forEachRemaining(i -> System.out.println(i));
            
            int pInt = iterator.next();
            System.out.printf("%d | ", pInt);
            total4 += pInt;
            
            // System.out.println(iterator.hasNext());
        }
        System.out.println("\ntotal4：" + total4);
        
        // System.out.println(iterator.hasNext());
        
        
        
        
    }
    
}
