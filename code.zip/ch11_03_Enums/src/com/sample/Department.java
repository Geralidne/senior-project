/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
// 自訂列舉型別
public enum Department {   
    
    // 列舉值
    // 宣告列舉常數值，必須放在程式的第一行
    // 如果建構子需要參數，參數須由列舉值提供
    // 人力資源、運營、法務、市場營銷
    HR("DEPT-1"), OPERATION("DEPT-2"), LEGAL("DEPT-3"), MARKETING("DEPT-4");
    
    // 屬性
    private String deptCode;
    
    // 建構子：不可以實作(new)列舉物件，因此建構子不可以宣告 public
    private Department(String deptCode){
        this.deptCode = deptCode;
    }
    
    // 方法
    public String getDeptCode(){
        return deptCode;
    }
}

