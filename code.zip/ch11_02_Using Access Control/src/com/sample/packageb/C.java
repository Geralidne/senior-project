/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample.packageb;

import com.sample.packagea.A;

/**
 *
 * @author User
 */
public class C extends A{
    
    // 以繼承的身分重新定義 class A 父類別的 display 方法
    @Override
    public void display(){
        System.out.println("類別 C 繼承類別 A，可以操作的成員...");
        // System.out.println("-w：" + w);
        // System.out.println(" x：" + x);
        System.out.println("#y：" + y);
        System.out.println("+z：" + z);
        System.out.println("==========");
        
        System.out.println("類別 C 實作類別 A 物件，可以操作的成員...");
        A a = new A();
        // System.out.println("-a.w：" + a.w);
        // System.out.println(" a.x：" + a.x);
        // System.out.println("#a.y：" + a.y);
        System.out.println("+a.z：" + a.z);
    } 
}
