/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String s1 = "JAVA";
        String s2 = "java";
        String s3 = "java";
        String s4 = new String("java");
        String s5 = new String("java");
        
        // 查看 s1 ~ s5 物件的記憶體位址
        System.out.println("s1：" + System.identityHashCode(s1));
        System.out.println("s2：" + System.identityHashCode(s2));
        System.out.println("s3：" + System.identityHashCode(s3));
        System.out.println("s4：" + System.identityHashCode(s4));
        System.out.println("s5：" + System.identityHashCode(s5));
        System.out.println("-----------------");
        
        // 比較字串
        // 用 == 是比較記憶體位址
        System.out.println("s1==s2：" + (s1==s2));
        System.out.println("s2==s3：" + (s2==s3));
        System.out.println("s4==s5：" + (s4==s5));
        
        // 比較字串內容
        System.out.println("s1、s5 大小寫視為不同符號：" + s1.equals(s5));
        System.out.println("s1、s5 大小寫視為相同符號：" + s1.equalsIgnoreCase(s5));
        System.out.println("-----------------");
        
        // 字串串接
        String a = "A";
        String b = "B";
        String c = "C";
        String d = "D";
        
        // a + b;  // 編譯失敗，使用【+】運算，a + b 的左邊需要有【=】指定
        // 由 print()、println() 輸出
        System.out.println(a + b);
        // 指定變數
        String temp1 = a + b;   // 將 a + b 串接的結果交給變數 temp1
        System.out.println("1. temp1：" + temp1);  // AB
        temp1.concat(c);   // concat() 是 String 類別提供字串串接的方法，將 temp1 字串串接 c --> ABC
        System.out.println("2. temp1：" + temp1);  // AB
        temp1 = temp1.concat(c);   // 將 temp1 字串串接 c --> ABC，再交給 temp1
        System.out.println("3. temp1：" + temp1);
        System.out.println("-----------");
        
        // 字串串接使用【+】
        String temp2 = a;      // A
        temp2 = temp2 + b + c; // ABC
        temp2 = temp2 + d;     // ABCD
        System.out.println("temp2：" + temp2);
        
        // 字串串接使用 StringBuilder 物件內容是可變的
        StringBuilder temp3 = new StringBuilder();
        temp3.append(a);  
        temp3.append(b).append(c);
        temp3.append(d);
        System.out.println("temp3：" + temp3);
        System.out.println("-----------");
        
        StringBuilder temp4 = new StringBuilder();
        for(int i=65; i<=90; i++){
            temp4.append((char)i);
        }
        System.out.println("temp4：" + temp4);
        
        StringBuilder temp5 = new StringBuilder();
        for(int i=65; i<=90; i++){
            if(i % 2 != 0){
                temp5.append((char)i);
            }else{
                temp5.append((char)(i + 32));
            }
        }
        System.out.println("temp5：" + temp5);
        System.out.println("-----------");
        
        // 字串常用方法
        String str = null;
        str = "";
        str = " This is java, That is python ";
        System.out.println("str：" + str);
        System.out.println("str 是否是空字串：" + str.isEmpty());
        System.out.println("str 字串長度：" + str.length());
        System.out.println("----------------");
        // 去除字串首尾空白符號
        str = str.trim();
        System.out.println("str 字串長度：" + str.length());
        System.out.println("          1         2         3");
        System.out.println("0123456789012345678901234567890");
        System.out.println(str);
        System.out.println("-------------------------------");
        System.out.println("第 10 個字元：" + str.charAt(9));
        System.out.println("a 最先出現的索引位置：" + str.indexOf('a'));
        System.out.println("a 最後出現的索引位置：" + str.lastIndexOf('a'));
        System.out.println("is 最先出現的索引位置：" + str.indexOf("is"));
        System.out.println("is 最後出現的索引位置：" + str.lastIndexOf("is"));
        System.out.println("P 最先出現的索引位置：" + str.indexOf('P'));     // 找不到資料回傳 -1
        System.out.println("-------------------------------");
        System.out.println("str.substring(14)：" + str.substring(14));
        System.out.println("str.substring(8, 12)：" + str.substring(8, 12));
        System.out.println("-------------------------------");
        System.out.println("str 是否是 This 開始的字串：" + str.startsWith("This"));
        System.out.println("str 是否是 python 結束的字串：" + str.endsWith("python"));
        System.out.println("轉大寫：" + str.toUpperCase());
        System.out.println("轉小寫：" + str.toLowerCase());
        System.out.println("-------------------------------");
        System.out.println("用 * 取代 is：" + str.replace("is", "*"));
        System.out.println("-------------------------------");
        
        // 將字串型態的數值資料轉成對應的數值型別
        String sh = "170.5";
        String sw = "65";
        
        double h = Double.parseDouble(sh);
        int w = Integer.parseInt(sw);
        double bmi = w / ((h/100)*(h/100));
        System.out.printf("身高：%.2f，體重：%d，BMI：%.2f%n", h, w, bmi);
        
        
        
        
    }
    
}
