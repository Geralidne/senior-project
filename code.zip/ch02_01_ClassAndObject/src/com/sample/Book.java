/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

import java.time.LocalDateTime;

/**
 *
 * @author User
 */
// 定義(自訂)類別
// [存取修飾字][修飾字] class 類別名稱{...}
//   public   (無)
//    (無)    abstract
//            final
public class Book {
    
    // 屬性：物件特徵(類別內、方法外的變數)
    // [存取修飾字][修飾字] 型別 名稱 [=值]
    // +name:String
    public String name;  // 書名
    public int price;    // 售價
    private LocalDateTime datetime;  // 查詢時間      
    
    // 建構子：建立物件初始化屬性
    // [存取修飾字] 類別名稱(參數列){...}
    public Book(){
        System.out.println("新書籍建立...");
    }
    
    // 方法：物件操作
    // [存取修飾字][修飾字] 回傳型別 方法名稱(參數列){...}
    public void display(){
        // 建立 datetime 物件
        datetime = LocalDateTime.now();  // 取得系統日期時間物件
        // 顯示書籍資訊
        System.out.println("書名：" + name);
        System.out.println("售價：" + price);
        System.out.println("查詢時間：" + datetime);
    }
    
}
