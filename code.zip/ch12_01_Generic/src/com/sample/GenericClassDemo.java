/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class GenericClassDemo {
    
    // 產生主方法快速鍵：先輸入 main 再按 <Tab> 
    public static void main(String[] args) {
        
        // 建立 CacheAny 物件時沒有指定 T 的型別，T 則以 Object 型別來處理資料
        CacheAny ca1 = new CacheAny();
        ca1.add(123);
        //                           取出的資料為 Object 型別，不可以直接計算，必須轉型回原料型別
        System.out.println("ca1：" + (int)ca1.get()*2);
        
        // 建立 CacheAny 物件時指定 T 的型別
        CacheAny<Integer> ca2 = new CacheAny<Integer>();
        ca2.add(123);
        System.out.println("ca2：" + ca2.get()*2);
        
        CacheAny<Double> ca3 = new CacheAny<>(); // Java 7 開始，new CacheAny<>(); 的 <> 內的型別可以省略
        ca3.add(123.0);
        System.out.println("ca3：" + ca3.get()*2);
        
        CacheAny<String> ca4 = new CacheAny();  // Java 7 開始，new CacheAny<>(); 的 <> 可以省略
        ca4.add("java");
        System.out.println("ca4：" + ca4.get().toUpperCase());
        System.out.println("-------------------------");
        
        CacheAny test1 = new CacheAny<String>();
        test1.add(123);    // Object 型別
        
        // 錯誤語法
        //var<Integer> test2 = new CacheAny();
        var test2 = new CacheAny();
        test2.add(123);   // Object 型別
        
        var test3 = new CacheAny<Integer>();
        test3.add(123);   // Integer 型別
        
        //------------------------------------------
        // 使用 匿名內部類別覆寫 CacheAny 的方法
        CacheAny<String> ca5 = new CacheAny<>(){   // Java 9 new CacheAny<>() 的 <> 內的型別可以省略，<> 要寫
            @Override
            public String get() {
                return super.get().toUpperCase();
            }
        };
        ca5.add("java");
        System.out.println("ca5：" + ca5.get());
        
        
    }
}


//----------------------------------------
// 自訂泛型類別
class CacheAny<T>{
    private T t;
    
    public void add(T t){
        this.t = t;
    }
    
    public T get(){
        return t;
    }
}

