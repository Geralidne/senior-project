/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        SubClass sub = new SubClass(3, 5);
//        sub.display();
    }
    
}

//---------------------------------------------------

// final 類別：不可以被繼承
final class SuperClass{
    
    // final 方法：子類別不可以重新定義
    public final void display(){
        
    }
}

//---------------------------------------------------
/*
class SubClass extends SuperClass{
    
    // 一般屬性初始化方式：1. 使用預設值 2.明確指定 3.使用建構子
    int a;
    int b = 2;
    int c;
    
    // final 屬性初始化方式：1.明確指定 2.使用建構子
    final int D = 4;
    final int E;
    
    public SubClass(int c, int E){
        System.out.printf("物件剛建立：a=%d, b=%d, c=%d%n", this.a, this.b, this.c);
        this.c = c;
        System.out.printf("物件建立：a=%d, b=%d, c=%d%n", this.a, this.b, this.c);
        System.out.println("-----------------");
        // System.out.printf("final 物件剛建立：D=%d, D=%d%n", this.D, this.E); // variable E might not have been initialized
        this.E = E;
        System.out.printf("final 屬性：D=%d, D=%d%n", this.D, this.E); 
        // this.D = 40;    // cannot assign a value to final variable D
        System.out.println("----------------");
    }

    @Override
    public void display() {
        // 修改 a、b、c
        a = 10;
        b = 20;
        c = 30;
        System.out.printf("方法修改：a=%d, b=%d, c=%d%n", this.a, this.b, this.c);
        // 嘗試修改 D、E
        // D = 40;   // cannot assign a value to final variable D
        // E = 50;   // cannot assign a value to final variable E
        
        // 方法內宣告常數
        final int F = 6;
        System.out.println("F=" + F);
        // F = 60; // cannot assign a value to final variable F
    }
    
    
}
*/