/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.SQLException;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {            
            doText();
        } catch (IOException ex) {
            System.out.println("main()：" + ex.getMessage());
        } catch (SQLException ex){
            System.out.println("main()：" + ex);
        } catch (MyException ex) {
            System.out.println("main()：" + ex + ex.getMessage());
        } catch(Exception ex){
            System.out.println("main()：" + ex);
        }
        System.out.println("結束!");
    }

    private static void doText() throws IOException, SQLException, MyException {
        double random = new Random().nextDouble(); // 0.0 ~ <1.0
        System.out.println("random：" + random);
        
        if(random >=0.8){
            // 建立 ArithmeticException 例外物件(Unchecked exceptions)
            // 建立例外物件： throw new 例外型別(自訂訊息)
            throw new ArithmeticException("除數不可為 0!");
        }else if(random >= 0.6){
            // 建立 IOException 例外物件(Checked Exception)
            throw new IOException("I/O 錯誤"); // 者個例外物件 doTest() 不處理，利用 throws 將例外物件拋回給呼叫端
        }else if(random >= 0.4){
            try {
                // 建立 SQLException 例外物件(Checked Exception)
                throw new SQLException("SQL 錯誤"); // 使用 try-catch 處理
            } catch (SQLException ex) {
                System.out.println("doTest()：SQL 事件紀錄完成");
                // 例外【再】拋
                throw ex;
            }            
        }else if(random >= 0.2){
            // 建立 MyException 例外物件(Checked Exception)
            throw new MyException(2266, "小明");
        }else{
            System.out.println("系統正常!");
        }
        
    }
    
}
