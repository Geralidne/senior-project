/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.sample;

/**
 *
 * @author User
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a = 1;
        int b = a;
        System.out.printf("1. a=%d, b=%d%n", a, b); // 1 1
        // 變更 a
        ++a;
        System.out.printf("2. a=%d, b=%d%n", a, b); // 2 1
        
        // 呼叫 doTest() 將 a 送過去
        doTest(a);
        System.out.println("5. a=" + a);
        
        Book book = new Book("Java SE 11", 700);
        System.out.println("6. " + book.display());   // [Java SE 11, 700]
        doTest(book);
        System.out.println("9. " + book.display());   // [Java SE 11, 900]
        
        String str = "java se";
        System.out.println("A. " + str);   // java se
        doTest(str);
        System.out.println("D. " + str);  // java se
    }

    private static void doTest(int a) {  // 2
        System.out.println("3. a=" + a); // 2
        ++a;  // 3
        System.out.println("4. a=" + a); // 3 
    }

    private static void doTest(Book book) {
        System.out.println("7. " + book.display());  // [Java SE 11, 700]
        book.price = 900;
        System.out.println("8. " + book.display()); // [Java SE 11, 900]
    }

    private static void doTest(String str) {
        System.out.println("B. " + str);  // java se
        str = str.toUpperCase();
        System.out.println("C. " + str);  // JAVA SE
    }
    
}
